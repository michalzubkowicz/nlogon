n!logon
Copyright (C) 2005 Micha� Zubkowicz
-----------------------------------------------------------------------
Niniejszy program jest wolnym oprogramowaniem; mo�esz go 
rozprowadza� dalej i/lub modyfikowa� na warunkach Powszechnej
Licencji Publicznej GNU, wydanej przez Fundacj� Wolnego
Oprogramowania - wed�ug wersji 2-giej tej Licencji lub kt�rej�
z p�niejszych wersji. 

Niniejszy program rozpowszechniany jest z nadziej�, i� b�dzie on 
u�yteczny - jednak BEZ JAKIEJKOLWIEK GWARANCJI, nawet domy�lnej 
gwarancji PRZYDATNO�CI HANDLOWEJ albo PRZYDATNO�CI DO OKRE�LONYCH 
ZASTOSOWA�. W celu uzyskania bli�szych informacji - Powszechna 
Licencja Publiczna GNU. 

Z pewno�ci� wraz z niniejszym programem otrzyma�e� te� egzemplarz 
Powszechnej Licencji Publicznej GNU (GNU General Public License);
je�li nie - napisz do Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.
-------------------------------------------------------------------------


1. DO CZEGO S�U�Y TEN PROGRAM

Ten program s�u�y do niby-logowania:) do domeny NT, a dok�adniej chodzi o uruchamianie skrypt�w z udzia�u /netlogon w systemie w Windows XP. Zast�puje okno logowania Windows XP, lub pozwala na u�ycie loginu i has�a z systemu.

Ikonka jest po�yczona z KDE 3.4, mam nadzieje �e si� nie obra��. 
W pracy wykorzysta�em bibliotek� TXMLINI 1.082, te� mam nadziej� �e nie b�dzie mia� mi za z�e:)

2. KONFIGURACJA

Wszelkie dane znajduj� si� w pliku konfiguracyjnym c:\config.xml. Zostaje on utworzony przy pierwszym uruchomieniu programu.

Mo�liwe opcje to: 
<last_user> - automatczynie zapisywana warto�� przy zamkni�ciu programu.
<use_windows_user> - 0 w przypadku gdy chcemy aby program zast�powa� logowanie windows (w przypadku gdy wszyscy pracuj� na jednym windowsowym u�ytkowniku, 1 w przypadku gdy chcemy aby program pobiera� dane z logowania windowsa.
<server_name> nazwa serwera. Nale�y pami�ta� o \\ na pocz�tku. 

