n!logon 0.2 - 20 kwietnia 2005
--------------------------------------------------

Oprogramowanie podlega licencji GPL, aby dowiedzie� si� wi�cej przeczytaj plik licencja.txt

Ten program s�u�y do niby-logowania:) do domeny NT, a dok�adniej chodzi o uruchamianie skrypt�w z udzia�u /netlogon w systemie w Windows XP. Zast�puje okno logowania Windows XP, lub pozwala na u�ycie loginu i has�a z systemu.

Ikonka jest po�yczona z KDE 3.4, mam nadzieje �e si� nie obra��. 
W pracy wykorzysta�em bibliotek� TXMLINI 1.082.