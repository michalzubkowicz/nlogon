TXMLINI 1.082
-------------------------------

Klasa TXMLINI jest open-source'owym zamiennikiem dla klasy TINIFile �rodowiska Delphi, pracuj�cym na plikach 
XML w taki sam spos�b, jak klasa TINIFile pracuje na plikach INI.

Obecna wersja jest wersj� stabiln�, ale je�li tylko znalaz�e� jakikliwiek b�ad to zg�o� go do naszego 
Bugtraqa na stronie projektu (http://www.sourceforge.net/projects/txmlini).

Je�li chcia�by� pom�c nam w rozwoju TXMLINI, masz pytania, zastrze�enia, propozycje to zg�o� to do mnie na e-mail: marcin.ktos@gmail.com. Mo�esz tak�e napisa� nowy w�tek na forum TXMLINI na stronie projektu.

Mi�ego korzystania z TXMLINI.

Pozdrawiam, Ktos
[19:03 2005-03-28]

TXMLINI class is an open-source equivalent of original TINIFile class of Delphi environment, but it works on
XML files instead of INI files.

This version is stable version. Anyway, if you has found any bug, please submit it to aut bug tracking 
system on a project site: http://www.sourceforge.net/projects/txmlini.

If you want to help is in developing TXMLINI, or you have any questions, suggestions ot sth, please mail me
at marcin.ktos@gmail.com or post new thread on TXMLINI forum on project site.

Have a lot of fun when using TXMLINI.

Ktos
[19:03 2005-03-28]

Licencja (licence): gpl.txt (Polish) or gpl-eng.txt (English)


[update - version 1.081]
in this version there is a bug #1083841 fixed
w tej wersji jest poprawiony b��d #1083841

[update - version 1.082]
fixed bug #1171959
poprawiony b��d #1171959